--CREATE SCHEMA company;

DROP TABLE company.dependent;
GO

DROP TABLE company.works_on;
GO

DROP TABLE company.project;
GO

DROP TABLE company.dept_locations;
GO

DROP TABLE company.employee;
GO
DROP TABLE company.department;
GO

CREATE TABLE company.department(
Dname VARCHAR(25),
Dnumber INT,
Mgr_ssn INT,
Mgr_start_date DATE,
PRIMARY KEY (Dnumber)
);

CREATE TABLE company.employee(
Fname VARCHAR(15),
Minit CHAR,
Lname VARCHAR(15),
SSN INT NOT NULL,
Bdate DATE,
Address VARCHAR(30),
Sex CHAR,
Salary DECIMAL(10,2),
Super_ssn INT,
Dno INT,
PRIMARY KEY (Ssn),
FOREIGN KEY (Super_ssn) REFERENCES company.employee(SSN),
FOREIGN KEY (Dno) REFERENCES company.department
);

CREATE TABLE company.dept_locations(
Dnumber INT NOT NULL,
DLocation VARCHAR(25) NOT NULL,
PRIMARY KEY (Dnumber, Dlocation),
FOREIGN KEY (Dnumber) REFERENCES company.department(Dnumber)
);

CREATE TABLE company.project(
Pname VARCHAR(25),
Pnumber INT NOT NULL,
Plocation VARCHAR(25),
Dnum INT,
PRIMARY KEY(Pnumber),
FOREIGN KEY (Dnum) REFERENCES company.department(Dnumber)
);

CREATE TABLE company.works_on(
Essn INT NOT NULL,
Pno INT NOT NULL,
Hours INT,
PRIMARY KEY (Essn, Pno),
FOREIGN KEY (Essn) REFERENCES company.employee(Ssn),
FOREIGN KEY (Pno) REFERENCES company.project(Pnumber)
);

CREATE TABLE company.dependent(
Essn INT NOT NULL,
Dependent_name VARCHAR(25),
Sex CHAR,
Bdate DATE,
Relationship VARCHAR(25),
PRIMARY KEY (Essn, Dependent_name),
FOREIGN KEY (Essn) REFERENCES company.employee(Ssn)
);